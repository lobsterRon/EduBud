﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Edu Bud")>
<Assembly: AssemblyDescription("Description :                                                    This application allow professionals to offer training courses to individuals to gain new knowledge and enhance their working.                                                                                                         Contact:                                                         For any suggestion or feedback, kindly contact us.                                                                           Cheah Yong Xhie +6016-9134900 roncheah@gmail.com                                           Ahmad Faqrullah +6012-45045092 ahmadabu@gmail.com")>
<Assembly: AssemblyCompany("Edu Bud Sdn. Bhd.")>
<Assembly: AssemblyProduct("Edu Bud")>
<Assembly: AssemblyCopyright("Copyright © HP 2022")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("c5a87bd8-a0aa-456c-9d3b-32e717da51ee")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
